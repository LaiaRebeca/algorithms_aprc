#include <stdio.h>
#include <stdlib.h>

int main( void ){
        float D;
        float C;
        float a;
        float r;
        //float Pi = 3.141592;

        printf( "Valor do raio do circulo:" );
        scanf( "%f", &r );

        D = 2 * r;
        C = 2 * 3.141592 * r;
        a = 3.141592 * r * r;
        
        printf( "Diametro = %.2f\n", D );

        printf( "Circuferencia = %.2f\n", C );
        
        printf( "Area = %.2f", a );

        return 0;


}