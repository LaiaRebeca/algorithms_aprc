# include <stdio.h>
# include <stdlib.h>

int main( void ){
        float fah;
        float cel;
        float temperatura;
        
        printf( "Temperatura em graus Fahrenheit: ");
        scanf( "%f", &fah );

        temperatura = fah - 32;
        cel = temperatura / 1.8;

        printf( "125.00 graus Faherenheit correspondem a %2.f graus Celsius ", cel );

        return 0;
}