# include <stdio.h>
# include <stdlib.h>

int main( void ){
        
        int n;
        int resultado;

        for ( int i = 15; i <= 30; i++){

                printf( "%d ", i * i);
        }
        return 0;
}