# include <stdio.h>
# include <stdlib.h>

int main( void ){
        for( int i = 20; i >= 0; i --) {
            printf( "%d ", i);
        }

        return 0;    
}